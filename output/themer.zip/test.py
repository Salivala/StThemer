for x in range(1,99):
    print(x)
