print("program running!")
print("wow!")
