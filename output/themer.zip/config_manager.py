"""" aldkjdlakwjd """
class ConfigManger:
    """ alkjdlakwjd """
    def __init__(self, filename=False):
        self.filename = filename

